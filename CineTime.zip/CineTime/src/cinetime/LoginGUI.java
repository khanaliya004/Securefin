package CineTime;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LoginGUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginBtn, registerBtn;

    public LoginGUI() {
        setTitle("CineTime - Login");
        setSize(350, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Set up a panel for better structure
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username field
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Username:"), gbc);

        gbc.gridx = 1;
        usernameField = new JTextField();
        panel.add(usernameField, gbc);

        // Password field
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField();
        panel.add(passwordField, gbc);

        // Buttons at the bottom
        loginBtn = new JButton("Login");
        registerBtn = new JButton("Register");

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(loginBtn, gbc);

        gbc.gridx = 1;
        panel.add(registerBtn, gbc);

        // Action listeners for buttons
        loginBtn.addActionListener(e -> authenticate());
        registerBtn.addActionListener(e -> openRegisterWindow());

        // Add the panel to the frame
        add(panel);

        setVisible(true);
    }

    // Method to authenticate the user
    private void authenticate() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Simple validation
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                dispose(); // Close the login window
                new MainMenuGUI(); // Open the main menu
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password.");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error while connecting to the database.");
            e.printStackTrace();
        }
    }

    // Method to open the registration window
    private void openRegisterWindow() {
        new RegisterGUI();
        dispose(); // Close the login window
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginGUI());
    }
}
