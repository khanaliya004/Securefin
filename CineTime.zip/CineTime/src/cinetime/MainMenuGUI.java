package CineTime;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class MainMenuGUI extends JFrame {

    public MainMenuGUI() {
        setTitle("CineTime - Movie Booking System");
        setSize(400, 600); // Increased size for more comfortable space
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Layout - using BoxLayout for better organization
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS)); 

        // Create and add buttons with their respective actions
        createAndAddButton("🎬 View All Movies", e -> new ViewMoviesGUI());
        createAndAddButton("🔍 Search Movie", e -> new SearchMovieGUI());
        createAndAddButton("🎟️ Book Ticket", e -> new BookTicketGUI());
        createAndAddButton("📖 View My Bookings", e -> new ViewBookingsGUI());

        // Exit button with message and exit functionality
        JButton exitBtn = new JButton("❌ Exit");
        exitBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        exitBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Thank you for using CineTime!");
            System.exit(0);
        });
        add(Box.createVerticalGlue()); // Adds vertical space before exit button
        add(exitBtn);

        // Set some padding around the frame
        add(Box.createVerticalStrut(20));

        // Display the frame
        setVisible(true);
    }

    // Helper method to create and add a button to the frame with its action listener
    private void createAndAddButton(String buttonText, ActionListener action) {
        JButton button = new JButton(buttonText);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(350, 50)); // Set maximum width and height for buttons
        button.setPreferredSize(new Dimension(350, 50)); // Maintain uniform button size
        button.addActionListener(action);
        add(button);
        add(Box.createVerticalStrut(10)); // Adds vertical spacing between buttons
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainMenuGUI()); // Launch the main menu
    }
}
