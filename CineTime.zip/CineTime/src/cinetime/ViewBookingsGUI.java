package CineTime;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ViewBookingsGUI extends JFrame {
    private JTextArea bookingsArea;

    public ViewBookingsGUI() {
        setupUI();
    }

    // Setup the UI layout and components
    private void setupUI() {
        setTitle("My Bookings");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Set layout
        setLayout(new BorderLayout(10, 10));

        // Create the text area to display bookings
        bookingsArea = new JTextArea();
        bookingsArea.setEditable(false);
        bookingsArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        
        // Add scroll to the text area
        JScrollPane scrollPane = new JScrollPane(bookingsArea);
        scrollPane.setPreferredSize(new Dimension(350, 250));
        add(scrollPane, BorderLayout.CENTER);

        // Load bookings data
        loadBookings();

        // Buttons for actions
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10)); // Centered buttons with space
        JButton cancelButton = new JButton("Cancel");
        JButton exitButton = new JButton("Exit to Main Menu");

        // Add buttons to the panel
        buttonPanel.add(cancelButton);
        buttonPanel.add(exitButton);

        // Add the panel to the frame
        add(buttonPanel, BorderLayout.SOUTH);

        // Action listener for cancel button
        cancelButton.addActionListener(e -> dispose());

        // Action listener for exit button
        exitButton.addActionListener(e -> {
            dispose();
            // new MainMenu();  // Uncomment if MainMenu class is ready
        });

        // Make the frame visible
        setVisible(true);
    }

    // Method to load and display bookings from the database
    private void loadBookings() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT b.booking_id, m.title, b.customer_name, b.tickets " +
                           "FROM bookings b " +
                           "JOIN movies m ON b.movie_id = m.id";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            StringBuilder sb = new StringBuilder("----- Your Bookings -----\n\n");
            while (rs.next()) {
                sb.append("Booking ID: ").append(rs.getInt("booking_id")).append("\n");
                sb.append("Movie: ").append(rs.getString("title")).append("\n");
                sb.append("Customer: ").append(rs.getString("customer_name")).append("\n");
                sb.append("Tickets: ").append(rs.getInt("tickets")).append("\n");
                sb.append("-----------------------------\n");
            }

            bookingsArea.setText(sb.toString());

        } catch (Exception e) {
            bookingsArea.setText("Error fetching bookings: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Main method to launch the ViewBookingsGUI
    public static void main(String[] args) {
        new ViewBookingsGUI();  // Launch the ViewBookingsGUI window
    }
}
