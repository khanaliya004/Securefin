package CineTime;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class SearchMovieGUI extends JFrame {
    private JTextField titleField;
    private JTextArea resultArea;

    public SearchMovieGUI() {
        // Frame properties
        setTitle("Search Movie");
        setSize(400, 500); // Increased size for better visibility
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Main Layout - Using BorderLayout
        setLayout(new BorderLayout(10, 10));

        // Input Panel for Search
        JPanel inputPanel = createInputPanel();
        add(inputPanel, BorderLayout.NORTH);

        // Result Area to display movie search results
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        add(scrollPane, BorderLayout.CENTER);

        // Buttons Panel (Cancel and Exit)
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Creates and returns the input panel with title field and search button
    private JPanel createInputPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout()); // Using GridBagLayout for better control
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components
        gbc.anchor = GridBagConstraints.CENTER;

        JLabel titleLabel = new JLabel("Enter Movie Title:");
        titleField = new JTextField(20);

        // Search button with proper size and spacing
        JButton searchBtn = new JButton("Search");
        searchBtn.setPreferredSize(new Dimension(150, 40));

        // Add components to the panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(titleLabel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(titleField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(searchBtn, gbc);

        // Search button action listener
        searchBtn.addActionListener(e -> searchMovie());

        return panel;
    }

    // Creates and returns the button panel with cancel and exit buttons
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10)); // Centering buttons and spacing

        JButton cancelButton = new JButton("Cancel");
        JButton exitButton = new JButton("Exit to Main Menu");

        // Adjust button sizes and layout
        cancelButton.setPreferredSize(new Dimension(120, 40));
        exitButton.setPreferredSize(new Dimension(150, 40));

        // Add components to panel
        panel.add(cancelButton);
        panel.add(exitButton);

        // Cancel button action listener
        cancelButton.addActionListener(e -> dispose());

        // Exit button action listener
        exitButton.addActionListener(e -> {
            dispose();
            // Uncomment and use this if you have a MainMenu class
            // new MainMenu();
        });

        return panel;
    }

    // Method to perform the search and display results
    private void searchMovie() {
        String title = titleField.getText().trim();

        // Check if the title field is empty
        if (title.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a movie title.");
            return;
        }

        // Perform search in database
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM movies WHERE title LIKE ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + title + "%");

            ResultSet rs = stmt.executeQuery();
            StringBuilder resultText = new StringBuilder();

            // Append results to the resultText
            while (rs.next()) {
                resultText.append("Title: ").append(rs.getString("title")).append("\n");
                resultText.append("Genre: ").append(rs.getString("genre")).append("\n");
                resultText.append("Duration: ").append(rs.getString("duration")).append("\n");

                // Fetch and handle time, check if it's available
                Time time = rs.getTime("time");
                if (time != null) {
                    resultText.append("Time: ").append(time.toString()).append("\n");
                } else {
                    resultText.append("Time: Not Available\n");
                }

                resultText.append("--------------------------\n");
            }

            // Display search results in the result area
            if (resultText.length() == 0) {
                resultArea.setText("No movies found.");
            } else {
                resultArea.setText(resultText.toString());
            }

        } catch (SQLException e) {
            resultArea.setText("Error occurred while searching: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Main method to launch the SearchMovieGUI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SearchMovieGUI());
    }
}
