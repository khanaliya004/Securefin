package CineTime;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class BookTicketGUI extends JFrame {
    private JTextField nameField, ticketsField, customerNameField;
    private JButton bookButton;

    public BookTicketGUI() {
        // Frame setup
        setTitle("Book Movie Ticket");
        setSize(400, 300);  // Larger size for better visibility
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Set layout manager
        setLayout(new BorderLayout(10, 10));

        // Create a panel for inputs (centered)
        JPanel inputPanel = createInputPanel();
        add(inputPanel, BorderLayout.CENTER);

        // Create a panel for buttons
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Create input panel for text fields and labels
    private JPanel createInputPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 10, 10));  // 4 rows, 2 columns, with spacing

        // Movie Name input
        panel.add(new JLabel("Movie Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        // Customer Name input
        panel.add(new JLabel("Your Name:"));
        customerNameField = new JTextField();
        panel.add(customerNameField);

        // Tickets input
        panel.add(new JLabel("Number of Tickets:"));
        ticketsField = new JTextField();
        panel.add(ticketsField);

        // Book Button
        bookButton = new JButton("Book Ticket");
        panel.add(bookButton);
        panel.add(new JLabel());  // Empty label for spacing

        // Action listener for book button
        bookButton.addActionListener(e -> bookTicket());

        return panel;
    }

    // Create button panel for Cancel and Exit buttons
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10)); // Center buttons with spacing

        // Cancel Button
        JButton cancelButton = new JButton("Cancel");
        panel.add(cancelButton);

        // Exit to Main Menu Button
        JButton exitButton = new JButton("Exit to Main Menu");
        panel.add(exitButton);

        // Action listeners for buttons
        cancelButton.addActionListener(e -> dispose());
        exitButton.addActionListener(e -> {
            dispose();
            // Uncomment if MainMenu class is available
            // new MainMenu();
        });

        return panel;
    }

    // Method to handle ticket booking
    private void bookTicket() {
        String movieName = nameField.getText().trim();
        String customerName = customerNameField.getText().trim();
        String ticketsText = ticketsField.getText().trim();

        // Check if any field is empty
        if (movieName.isEmpty() || customerName.isEmpty() || ticketsText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        try {
            int tickets = Integer.parseInt(ticketsText);

            // Database connection
            try (Connection conn = DBConnection.getConnection()) {
                if (conn == null) {
                    JOptionPane.showMessageDialog(this, "Database connection failed.");
                    return;
                }

                // Check if the movie exists
                PreparedStatement checkStmt = conn.prepareStatement("SELECT * FROM movies WHERE title = ?");
                checkStmt.setString(1, movieName);
                ResultSet rs = checkStmt.executeQuery();

                if (!rs.next()) {
                    JOptionPane.showMessageDialog(this, "Movie not found.");
                    return;
                }

                int movieId = rs.getInt("id"); // Get movie ID for booking

                // Insert booking record
                PreparedStatement insertStmt = conn.prepareStatement(
                        "INSERT INTO bookings (movie_id, customer_name, tickets) VALUES (?, ?, ?)"
                );
                insertStmt.setInt(1, movieId);
                insertStmt.setString(2, customerName);
                insertStmt.setInt(3, tickets);

                int rows = insertStmt.executeUpdate();
                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "Ticket(s) booked successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Booking failed.");
                }
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid number of tickets.");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    // Main method to launch the BookTicketGUI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BookTicketGUI()); // Launch the BookTicketGUI window
    }
}
