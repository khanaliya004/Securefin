package CineTime;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.SimpleDateFormat;

public class ViewMoviesGUI extends JFrame {
    private JTextArea movieArea;

    public ViewMoviesGUI() {
        // Frame properties
        setTitle("Available Movies");
        setSize(600, 600);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Text area to display movie information
        movieArea = new JTextArea();
        movieArea.setEditable(false);
        movieArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(movieArea);
        add(scrollPane, BorderLayout.CENTER);

        // Display available movies
        displayMovies();

        // Panel for buttons (Cancel and Exit)
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        // Buttons
        JButton cancelButton = new JButton("Cancel");
        JButton exitButton = new JButton("Exit to Main Menu");

        // Add buttons to the panel
        buttonPanel.add(cancelButton);
        buttonPanel.add(exitButton);

        // Add the button panel to the bottom of the frame
        add(buttonPanel, BorderLayout.SOUTH);

        // Action listener for Cancel button
        cancelButton.addActionListener(e -> dispose());

        // Action listener for Exit button (to return to main menu)
        exitButton.addActionListener(e -> {
            dispose();
            // new MainMenu(); // Uncomment to open the MainMenu window (if you have the class)
        });

        setVisible(true);
    }

    private void displayMovies() {
        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                movieArea.setText("Database connection failed.");
                return;
            }

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM movies");

            StringBuilder sb = new StringBuilder("----- Available Movies -----\n\n");

            // Formatting and displaying movie details with time if available
            while (rs.next()) {
                sb.append("ID: ").append(rs.getInt("id")).append("\n");
                sb.append("Title: ").append(rs.getString("title")).append("\n");
                sb.append("Genre: ").append(rs.getString("genre")).append("\n");
                sb.append("Duration: ").append(rs.getString("duration")).append("\n");

                // Check if the time is available and display it
                Time time = rs.getTime("time"); // Retrieve time as a Time object
                if (time != null) {
                    // Format the time to a readable string (HH:mm:ss)
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                    sb.append("Time: ").append(sdf.format(time)).append("\n");
                } else {
                    sb.append("Time: Not Available\n");
                }
                sb.append("------------------------------\n");
            }

            movieArea.setText(sb.toString());

        } catch (Exception e) {
            movieArea.setText("Error fetching movies: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Main method to run the program
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewMoviesGUI());  // Start the ViewMoviesGUI window
    }
}
