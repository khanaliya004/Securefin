package CineTime;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class RegisterGUI extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;

    public RegisterGUI() {
        setupUI();
    }

    // Set up the user interface with improved layout
    private void setupUI() {
        setTitle("CineTime - Register");
        setSize(350, 200);  // Adjusted size for a better layout
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));  // Using BorderLayout for better spacing

        // Center panel for inputs and button
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(3, 2, 10, 10));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));  // Add padding around

        // Username
        centerPanel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        centerPanel.add(usernameField);

        // Password
        centerPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        centerPanel.add(passwordField);

        // Register Button
        JButton registerBtn = new JButton("Register");
        centerPanel.add(registerBtn);
        
        // Register Button Action
        registerBtn.addActionListener(e -> register());

        // Adding the center panel to the frame
        add(centerPanel, BorderLayout.CENTER);

        // A bottom panel to add some space for future customization or any footer
        JPanel bottomPanel = new JPanel();
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Register the user
    private void register() {
        String username = usernameField.getText();
        String password = String.valueOf(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            // Check if the username already exists
            if (isUsernameExists(conn, username)) {
                JOptionPane.showMessageDialog(this, "Username already exists.");
            } else {
                // Register the new user
                if (insertUser(conn, username, password)) {
                    JOptionPane.showMessageDialog(this, "Registration successful! Welcome " + username + "!");
                    dispose();
                    new MainMenuGUI(); // Go to Main Menu after registration
                } else {
                    JOptionPane.showMessageDialog(this, "Registration failed. Please try again.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error during registration.");
        }
    }

    // Check if the username already exists in the database
    private boolean isUsernameExists(Connection conn, String username) throws SQLException {
        PreparedStatement checkStmt = conn.prepareStatement("SELECT * FROM users WHERE username = ?");
        checkStmt.setString(1, username);
        ResultSet rs = checkStmt.executeQuery();
        return rs.next(); // If user exists, return true
    }

    // Insert a new user into the database
    private boolean insertUser(Connection conn, String username, String password) throws SQLException {
        PreparedStatement insertStmt = conn.prepareStatement("INSERT INTO users (username, password) VALUES (?, ?)");
        insertStmt.setString(1, username);
        insertStmt.setString(2, password);
        int rowsInserted = insertStmt.executeUpdate();
        return rowsInserted > 0; // Return true if the insertion was successful
    }

    // Main method to launch the RegisterGUI
    public static void main(String[] args) {
        new RegisterGUI();  // Launch the registration window
    }
}
